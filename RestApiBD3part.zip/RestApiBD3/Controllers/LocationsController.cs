﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using RestApiBD3.Models;

namespace RestApiBD3.Controllers
{
    public class LocationsController : ApiController
    {
        private SistemaBEntities db = new SistemaBEntities();

        [HttpGet]
        public HttpResponseMessage Listar()
        {
            var info = db.locations.Select(s => new
            {
                s.idlocation,
                s.Name,
                s.Descript,
                s.Address,
                s.idboss,
                s.idcountry,
                s.idmunicipio
            }).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, info);
        }

        [HttpGet]
        public HttpResponseMessage BuscarPorId(int id)
        {
            var info = db.locations.Where(w => w.idlocation == id)
                .Select(s => new
                {
                    s.idlocation,
                    s.Name,
                    s.Descript,
                    s.Address,
                    s.idboss,
                    s.idcountry,
                    s.idmunicipio

                }).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, info);
        }

        [HttpPost]
        public HttpResponseMessage Nuevo([FromBody]location st)
        {
            string respuesta = "";
            try
            {
                location NUEVO = new location();
                NUEVO.Name = st.Name;
                NUEVO.Descript = st.Descript;
                NUEVO.Address = st.Address;
                NUEVO.idboss = st.idboss;
                NUEVO.idcountry = st.idcountry;
                NUEVO.idmunicipio = st.idmunicipio;
                db.locations.Add(NUEVO);
                db.SaveChanges();
                respuesta = "01: Añadir campo exitoso";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error al grabar " + error.Message;
                return Request.CreateResponse(HttpStatusCode.Conflict, respuesta);
            }

        }

        [HttpPut]
        public HttpResponseMessage Change([FromBody]location st)
        {
            string respuesta = "";
            try
            {
                db.Entry(st).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                respuesta = "Updated";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error saving " + error.Message;
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
        }

        [HttpDelete]
        public HttpResponseMessage Deletelocation([FromBody]location st)
        {
            string respuesta = "";
            try
            {
                db.Entry(st).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
                respuesta = "Deleted";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error deleting " + error.Message;
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }

        }
    }
}
