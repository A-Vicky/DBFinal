﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using RestApiBD3.Models;

namespace RestApiBD3.Controllers
{
    public class StateController : ApiController
    {
        private SistemaBEntities db = new SistemaBEntities();

        [HttpGet]
        public HttpResponseMessage ListarStates()
        {
            var info = db.states.Select(s => new
            {
                s.id,
                s.Name
            }).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, info);
        }

        [HttpGet]
        public HttpResponseMessage BuscarStatePorId(int id)
        {
            var info = db.states.Where(w => w.id == id)
                .Select(s => new
                {
                    s.id,
                    s.Name
                }).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, info);
        }

        [HttpPost]
        public HttpResponseMessage NuevaState([FromBody]state st)
        {
            string respuesta = "";
            try
            {
                state NUEVO = new state();
                NUEVO.Name = st.Name;
                db.states.Add(NUEVO);
                db.SaveChanges();
                respuesta = "01: Añadir Departamento exitoso";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error al grabar " + error.Message;
                return Request.CreateResponse(HttpStatusCode.Conflict, respuesta);
            }

        }

        [HttpPut]
        public HttpResponseMessage ChangeState([FromBody]state st)
        {
            string respuesta = "";
            try
            {
                db.Entry(st).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                respuesta = " Updated";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error saving " + error.Message;
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
        }

        [HttpDelete]
        public HttpResponseMessage DeletePet([FromBody]state st)
        {
            string respuesta = "";
            try
            {
                db.Entry(st).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
                respuesta = "Deleted";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error  " + error.Message;
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }

        }
    }
}
