﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using RestApiBD3.Models;

namespace RestApiBD3.Controllers
{
    public class StatusofcrimeController : ApiController
    {
        private SistemaBEntities db = new SistemaBEntities();

        [HttpGet]
        public HttpResponseMessage Listar()
        {
            var info = db.statusofcrimes.Select(s => new
            {
                s.id,
                s.Name,
                s.Descript
            }).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, info);
        }

        [HttpGet]
        public HttpResponseMessage BuscarPorId(int id)
        {
            var info = db.statusofcrimes.Where(w => w.id == id)
                .Select(s => new
                {
                    s.id,
                    s.Name,
                    s.Descript
                }).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, info);
        }

        [HttpPost]
        public HttpResponseMessage Nuevo([FromBody]statusofcrime st)
        {
            string respuesta = "";
            try
            {
                statusofcrime NUEVO = new statusofcrime();
                NUEVO.Name = st.Name;
                NUEVO.Descript = st.Descript;
                db.statusofcrimes.Add(NUEVO);
                db.SaveChanges();
                respuesta = "01: Añadir campo exitoso";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error al grabar " + error.Message;
                return Request.CreateResponse(HttpStatusCode.Conflict, respuesta);
            }

        }

        [HttpPut]
        public HttpResponseMessage Change([FromBody]statusofcrime st)
        {
            string respuesta = "";
            try
            {
                db.Entry(st).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                respuesta = "Updated";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error saving " + error.Message;
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
        }

        [HttpDelete]
        public HttpResponseMessage Deletestate([FromBody]statusofcrime st)
        {
            string respuesta = "";
            try
            {
                db.Entry(st).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
                respuesta = "Deleted";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error deleting " + error.Message;
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }

        }
    }
}
