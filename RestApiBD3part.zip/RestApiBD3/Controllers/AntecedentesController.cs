﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using RestApiBD3.Models;

namespace RestApiBD3.Controllers
{
    public class AntecedentesController : ApiController
    {
        private SistemaBEntities db = new SistemaBEntities();

        [HttpGet]
        public HttpResponseMessage Listar()
        {
            var info = db.Antecedentes.Select(s => new
            {
                s.arrestdoc,
                s.Commited,
                s.Caught,
                s.Preventivo,
                s.Type_of_Crime,
                s.fine,
                s.idcriminal,
                s.Names,
                s.Lnames,
                s.Gender,
                s.CivilStatus,
                s.Status,
                s.Status_Description,
                s.badgeid,
                s.Puesto
            }).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, info);
        }

        [HttpGet]
        public HttpResponseMessage BuscarPorId(string id)
        {
            var info = db.Antecedentes.Where(w => w.idcriminal == id)
                .Select(s => new
                {
                    s.arrestdoc,
                    s.Commited,
                    s.Caught,
                    s.Preventivo,
                    s.Type_of_Crime,
                    s.fine,
                    s.idcriminal,
                    s.Names,
                    s.Lnames,
                    s.Gender,
                    s.CivilStatus,
                    s.Status,
                    s.Status_Description,
                    s.badgeid,
                    s.Puesto
                }).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, info);
        }

        [HttpPost]
        public HttpResponseMessage Nuevo([FromBody]Antecedente s)
        {
            string respuesta = "";
            try
            {
                Antecedente NUEVO = new Antecedente();
                NUEVO.arrestdoc = s.arrestdoc;
                NUEVO.Commited = s.Commited;
                NUEVO.Caught = s.Caught;
                NUEVO.Preventivo = s.Preventivo;
                NUEVO.Type_of_Crime = s.Type_of_Crime;
                NUEVO.fine = s.fine;
                NUEVO.idcriminal = s.idcriminal;
                NUEVO.Names = s.Names;
                NUEVO.Lnames = s.Lnames;
                NUEVO.Gender = s.Gender;
                NUEVO.CivilStatus = s.CivilStatus;
                NUEVO.Status = s.Status;
                NUEVO.Status_Description = s.Status_Description;
                NUEVO.badgeid = s.badgeid;
                NUEVO.Puesto = s.Puesto;
                db.Antecedentes.Add(NUEVO);
                db.SaveChanges();
                respuesta = "01: Añadir campo exitoso";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error al grabar " + error.Message;
                return Request.CreateResponse(HttpStatusCode.Conflict, respuesta);
            }

        }

        [HttpPut]
        public HttpResponseMessage Change([FromBody]Antecedente st)
        {
            string respuesta = "";
            try
            {
                db.Entry(st).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                respuesta = "Updated";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error saving " + error.Message;
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
        }

        [HttpDelete]
        public HttpResponseMessage Deletestate([FromBody]Antecedente st)
        {
            string respuesta = "";
            try
            {
                db.Entry(st).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
                respuesta = "Deleted";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error deleting " + error.Message;
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }

        }
    }
}
