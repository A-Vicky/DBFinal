﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using RestApiBD3.Models;

namespace RestApiBD3.Controllers
{
    public class AgentController : ApiController
    {
        private SistemaBEntities db = new SistemaBEntities();

        [HttpGet]
        public HttpResponseMessage Listar()
        {
            var info = db.agents.Select(s => new
            {
                s.badgeid,
                s.cel,
                s.phone,
                s.idperson,
                s.idposition,
                s.idlocations
            }).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, info);
        }

        [HttpGet]
        public HttpResponseMessage BuscarPorId(int id)
        {
            var info = db.agents.Where(w => w.badgeid == id)
                .Select(s => new
                {
                    s.badgeid,
                    s.cel,
                    s.phone,
                    s.idperson,
                    s.idposition,
                    s.idlocations
                }).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, info);
        }

        [HttpPost]
        public HttpResponseMessage NuevaState([FromBody]agent st)
        {
            string respuesta = "";
            try
            {
                agent NUEVO = new agent();
                NUEVO.cel = st.cel;
                NUEVO.phone = st.phone;
                NUEVO.idperson = st.idperson;
                NUEVO.idposition = st.idposition;
                NUEVO.idlocations = st.idlocations;
                db.agents.Add(NUEVO);
                db.SaveChanges();
                respuesta = "01: Añadir Departamento exitoso";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error al grabar " + error.Message;
                return Request.CreateResponse(HttpStatusCode.Conflict, respuesta);
            }

        }

        [HttpPut]
        public HttpResponseMessage Change([FromBody]agent st)
        {
            string respuesta = "";
            try
            {
                db.Entry(st).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                respuesta = " Updated";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error saving " + error.Message;
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
        }

        [HttpDelete]
        public HttpResponseMessage Delete([FromBody]agent st)
        {
            string respuesta = "";
            try
            {
                db.Entry(st).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
                respuesta = "Deleted";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error  " + error.Message;
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }

        }
    }
}
