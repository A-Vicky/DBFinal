﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using RestApiBD3.Models;

namespace RestApiBD3.Controllers
{
    public class PersonController : ApiController
    {
        private SistemaBEntities db = new SistemaBEntities();

        [HttpGet]
        public HttpResponseMessage Listar()
        {
            var info = db.people.Select(s => new
            {
                s.cui,
                s.Names,
                s.Lnames,
                s.Birthdate,
                s.Gender,
                s.Address,
                s.idcountry,
                s.idmunicipio,
                s.civilstatusid
            }).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, info);
        }

        [HttpGet]
        public HttpResponseMessage BuscarPorId(string id)
        {
            var info = db.people.Where(w => w.cui == id)
                .Select(s => new
                {
                    s.cui,
                    s.Names,
                    s.Lnames,
                    s.Birthdate,
                    s.Gender,
                    s.Address,
                    s.idcountry,
                    s.idmunicipio,
                    s.civilstatusid
                }).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, info);
        }

        [HttpPost]
        public HttpResponseMessage Nuevo([FromBody]person st)
        {
            string respuesta = "";
            try
            {
                person NUEVO = new person();
                NUEVO.cui = st.cui;
                NUEVO.Names = st.Names;
                NUEVO.Lnames = st.Lnames;
                NUEVO.Birthdate = st.Birthdate;
                NUEVO.Gender = st.Gender;
                NUEVO.Address = st.Address;
                NUEVO.idcountry = st.idcountry;
                NUEVO.idmunicipio = st.idmunicipio;
                NUEVO.civilstatusid = st.civilstatusid;
                db.people.Add(NUEVO);
                db.SaveChanges();
                respuesta = "01: Añadir campo exitoso";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error al grabar " + error.Message;
                return Request.CreateResponse(HttpStatusCode.Conflict, respuesta);
            }

        }

        [HttpPut]
        public HttpResponseMessage Change([FromBody]person st)
        {
            string respuesta = "";
            try
            {
                db.Entry(st).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                respuesta = "Updated";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error saving " + error.Message;
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
        }

        [HttpDelete]
        public HttpResponseMessage Deletestate([FromBody]person st)
        {
            string respuesta = "";
            try
            {
                db.Entry(st).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
                respuesta = "Deleted";
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }
            catch (Exception error)
            {
                respuesta = "99: Error deleting " + error.Message;
                return Request.CreateResponse(HttpStatusCode.OK, respuesta);
            }

        }
    }
}
