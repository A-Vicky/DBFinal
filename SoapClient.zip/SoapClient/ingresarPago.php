<?php
  include './client.php';
  $data = array('dpi'=>$_POST['cui'],'anio' => date("Y"));
  $respuesta=  $client->ver($data);
  if($respuesta!="false"){
    $_SESSION['resultado']="sin error";
  }
  elseif($respuesta=="false"){
    session_start();
      $_SESSION['resultado']="error";
    header("Location: index.php ");
  }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <!-- Compiled and minified JavaScript -->

    <style>
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type=number] {
            -moz-appearance: textfield;
        }

        .card {
            margin-top: 2em;
            padding-top: 1em;
            padding-bottom: 1em;
        }
    </style>
</head>

<body>
    <nav>
        <div class="nav-wrapper  blue-grey darken-4">
            <a href="#" class="brand-logo center">Sistema de pagos partidas</a>
            <ul id="nav-mobile" class="left hide-on-med-and-down">
                <li><a href="index.php">Regresar</a></li>
            </ul>
        </div>
    </nav>

    <div class="row">
        <div class="col l8  offset-l2">
            <div class="card">
                <span>fecha actual: <?php echo date("Y/m/d"); ?></span>
                <div class="card-content">
                <form action="realizarPago.php" name="log" method="post">
                    <?php echo '<input type="number" value="'.$respuesta.'" 
                    style="display:none;" name="id" >'; ?>
                    <div class="row">
                        <div class="input-field col l6 offset-l2">
                            <input placeholder="" id="cui" name="cantidad" type="number" class="validate">
                            <label for="first_name">Ingrese cantidad a pagar</label>
                        </div>
                        <div class="input-field col l4 ">
                            <button class="btn  blue-grey darken-4">Realizar pago</button>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>

</html>