<?php
class Client{
    public function __construct()
    {
            $params = array("location"=>"http://localhost/www/soap/server.php",
            'uri'=> "urn://www/soap/server.php",
            'trace'=>1);
        $this->instance=new SoapClient(NUll,$params);
    }

    public function ver($dpi){
        return $this->instance->__soapCall('verificarBoleto',$dpi);
    }

    public function pago($arreglo){
        return $this->instance->__soapCall('realizarPago',$arreglo);
    }

}

$client=new Client;
?>