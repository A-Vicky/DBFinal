<?php
session_start();
$_SESSION['cui']=$_POST['cui'];
if($_POST['opcion']=="verificar"){
    header("Location: verificarPago.php ");
  }
  elseif($_POST['opcion']=="pagar"){
    header("Location: ingresarPago.php ");
  }

?>
