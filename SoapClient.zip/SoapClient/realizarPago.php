<?php
  include './client.php';
  $data = array('persona'=>$_POST['id'],'fecha' => date("Y/m/d"),'cantidad'=>$_POST['cantidad'],
    'tipo'=>"1");
  $respuesta=  $client->pago($data);
    if($respuesta=="pago realizado"){
        session_start();
        $_SESSION['resultado']="pago realizado";
        header("Location: index.php ");
    }
    echo 'error';

  ?>