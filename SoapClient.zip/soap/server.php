<?php 
    class server
    {

        public function __construct()
        {
            
        }

        public function verificarBoleto($dpi,$anio){    
            require 'data/functions.php';
            $exec=new Funciones();
            $pers=$exec->verificarBoletoDeOrnato($dpi,$anio);
            if ($pers->num_rows > 0){             
                $rows = [];
                while($row = mysqli_fetch_array($pers))
                {
                    $rows[] = $row;
                }
                return $rows[0]['id'];
             }
             else return "false";
        }  

        public function verificarPartida($dpi,$anio){    
            require 'data/functions.php';
            $exec=new Funciones();
            $pers=$exec->verificarBoletoDeOrnato($dpi,$anio);
            if ($pers->num_rows > 0){             
                $rows = [];
                while($row = mysqli_fetch_array($pers))
                {
                    $rows[] = $row;
                }
                return "true";
             }
             else return "false";
        } 


        public function realizarPago($persona,$fecha,$cantidad,$tipo){
            require 'data/functions.php';
            $exec=new Funciones();
            $pers=$exec->PagoPartida($persona,$fecha,$cantidad,$tipo);
            return "pago realizado";
        } 
    }

$params = array("uri"=>"www/soap/server.php");
$server = new SoapServer(NULL,$params);
$server->setClass("server");
$server->handle();
?>